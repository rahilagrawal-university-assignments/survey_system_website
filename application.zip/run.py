from flask_script import Manager
from routes import app, init_DB


manager = Manager(app)


@manager.command
def start():
    init_DB()
    app.run()


if __name__ == "__main__":
    manager.run()
